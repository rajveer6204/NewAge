module inventory-management
